package com.example.telaprincipalbanco

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val idSaldoAtual = findViewById<TextView>(R.id.idSaldoAtual)

        var idSaldo = idSaldoAtual.text
        var saldoAtual = idSaldo.toString().toDouble()


        val btnSair = findViewById<Button>(R.id.idBtnSair)
        btnSair.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val btnEmprestimo = findViewById<Button>(R.id.idBtnEmprestimo)
        btnEmprestimo.setOnClickListener {
            saldoAtual = saldoAtual + 1000
            idSaldoAtual.setText(saldoAtual.toString())
        }


        val btnSaque = findViewById<Button>(R.id.idBtnSaque)
        btnSaque.setOnClickListener {
            var saquex = (saldoAtual.toString().toDouble() - 500).toDouble()
            saldoAtual = saquex
            idSaldoAtual.setText(saquex.toString())

        }

}
}